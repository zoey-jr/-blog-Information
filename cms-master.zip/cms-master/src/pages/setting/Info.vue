<template>
	<div class="info">
		基础设置		
	</div>
</template>
