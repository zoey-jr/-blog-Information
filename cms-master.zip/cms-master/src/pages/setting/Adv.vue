<template>
	<div class="adv">
		广告设置
	</div>
</template>