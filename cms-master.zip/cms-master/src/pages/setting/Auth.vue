<template>
	<div class="auth">
		权限设置
	</div>
</template>